Laundry Service Website 
What’s This About?

This is a simple landing page for a laundry service built with HTML, CSS, and Bootstrap.
It’s designed to look clean, modern, and user-friendly, so anyone can see your services and book a pickup easily.

Features 
Responsive Navbar with logo and links
Username/Login button
Hero section with big headline, description, and a Book Service button
Stylish laundry-themed image
Clean design using Bootstrap and Flexbox
Tech Stack 
HTML5
CSS